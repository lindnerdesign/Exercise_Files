// Run this program by navigating to it in terminal/bash.
// Then run node Hello.js.
